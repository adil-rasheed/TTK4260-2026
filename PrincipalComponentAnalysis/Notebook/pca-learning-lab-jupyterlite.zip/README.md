# PCA Learning Lab (starter)

This is a lightweight starter implementing the split-panel layout:
- Left: notebook/visualization pane (renders your `.ipynb` file)
- Right: chatbot pane (stubbed, ready to wire to your LLM backend)

## Run

```bash
npm install
npm run dev
```

Then open the local URL printed by Vite.

## Where to extend next

- Make notebook cells selectable (so the chat can explain "this code/output").
- Add "guided mode" steps (already extracted from level-1 markdown headers).
- Add an execution backend:
  - Option A: embed JupyterLite (browser kernel) for fully client-side execution
  - Option B: connect to a Jupyter Server kernel for full Python package support

## Enable in-browser execution with JupyterLite (no server)

This repo can embed a JupyterLite JupyterLab instance in the left pane (tab **Run**).

### 1) Build JupyterLite into the Vite `public/` folder

From the repo root:

```bash
python -m pip install -r jupyterlite/requirements.txt
jupyter lite build --contents jupyterlite/content --output-dir public/jupyterlite
```

JupyterLite is a static site; after this, Vite will serve it at `/jupyterlite/...`. citeturn0search0turn0search13

### 2) Start the app

```bash
npm run dev
```

Open the app and click **Run** to use JupyterLab-in-the-browser.

### Optional: host ↔ iframe communication

- Setting `"exposeAppInBrowser": true` makes a `window.jupyterapp` global available inside the iframe. citeturn0search3
- For a more structured API (execute commands from host page), you can use the `jupyter-iframe-commands` extension. citeturn0search2turn0search7
