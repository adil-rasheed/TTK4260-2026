import React, { useMemo, useState } from "react";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";

import { TopBar } from "./components/TopBar";
import { NotebookPane } from "./components/NotebookPane";
import { ChatPane } from "./components/ChatPane";
import type { Step } from "./lib/notebook";

export default function App() {
  const [activeContext, setActiveContext] = useState<{ label: string; text: string } | null>(null);
  const [progress, setProgress] = useState({ stepIdx: 0, steps: [] as Step[] });

  const progressText = useMemo(() => {
    const total = progress.steps.length || 0;
    const current = total ? progress.stepIdx + 1 : 0;
    return total ? `Progress: ${current}/${total}` : "Progress: —";
  }, [progress]);

  return (
    <div style={styles.app}>
      <TopBar title="PCA Learning Lab" progressText={progressText} onSettings={() => alert("Settings (stub)")} />

      <PanelGroup direction="horizontal" style={styles.panels}>
        <Panel defaultSize={65} minSize={40}>
          <NotebookPane
            notebookUrl="/notebooks/PCA_McDonald_DA.ipynb"
            onSelectContext={setActiveContext}
            onStepChange={(stepIdx, steps) => setProgress({ stepIdx, steps })}
          />
        </Panel>

        <PanelResizeHandle style={styles.handle} />

        <Panel defaultSize={35} minSize={25}>
          <ChatPane
            activeContext={activeContext}
            onQuickAction={(a) => {
              if (a === "explain_plot") alert("Explain plot (wire to your backend + selected output).");
              if (a === "quiz_me") alert("Quiz me (wire to your quiz engine).");
              if (a === "whats_next") alert("What's next (use steps + mastery signals).");
            }}
          />
        </Panel>
      </PanelGroup>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  app: { height: "100vh", display: "flex", flexDirection: "column", fontFamily: "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial" },
  panels: { flex: 1, minHeight: 0 },
  handle: { width: 8, background: "#f3f4f6", cursor: "col-resize" },
};
