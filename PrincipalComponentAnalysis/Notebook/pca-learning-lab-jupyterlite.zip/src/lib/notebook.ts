export type NotebookCell = {
  cell_type: "markdown" | "code" | string;
  source?: string[] | string;
  metadata?: Record<string, unknown>;
  execution_count?: number | null;
  outputs?: unknown[];
};

export type Notebook = {
  cells: NotebookCell[];
  metadata?: Record<string, unknown>;
  nbformat?: number;
  nbformat_minor?: number;
};

export type Step = {
  id: string;
  title: string;
  // Index into notebook.cells where this step starts
  startCellIndex: number;
};

function lines(src?: string[] | string): string[] {
  if (!src) return [];
  return Array.isArray(src) ? src.join("").split("\n") : String(src).split("\n");
}

export function extractStepsFromMarkdownHeaders(nb: Notebook): Step[] {
  // Heuristic: use level-1 markdown headers as "modules"
  const steps: Step[] = [];
  nb.cells.forEach((cell, idx) => {
    if (cell.cell_type !== "markdown") return;
    for (const line of lines(cell.source)) {
      const m = /^(#)\s+(.*)$/.exec(line.trim());
      if (m) {
        const title = m[2].trim();
        steps.push({ id: `cell-${idx}`, title, startCellIndex: idx });
      }
    }
  });
  // Fallback to a single step
  if (steps.length === 0) steps.push({ id: "all", title: "Notebook", startCellIndex: 0 });
  return steps;
}

export function cellToPlainText(cell: NotebookCell): string {
  const src = Array.isArray(cell.source) ? cell.source.join("") : (cell.source ?? "");
  return String(src);
}
