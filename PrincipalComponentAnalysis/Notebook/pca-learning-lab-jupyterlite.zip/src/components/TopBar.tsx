import React from "react";

export function TopBar(props: { title: string; progressText: string; onSettings?: () => void }) {
  return (
    <div style={styles.bar}>
      <div style={styles.title}>{props.title}</div>
      <div style={styles.right}>
        <div style={styles.progress}>{props.progressText}</div>
        <button style={styles.iconBtn} onClick={props.onSettings} aria-label="Settings">
          ⚙️
        </button>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  bar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "10px 12px",
    borderBottom: "1px solid #e5e7eb",
    position: "sticky",
    top: 0,
    background: "white",
    zIndex: 10,
  },
  title: { fontWeight: 700 },
  right: { display: "flex", alignItems: "center", gap: 10 },
  progress: { fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace", fontSize: 12, opacity: 0.8 },
  iconBtn: { border: "1px solid #e5e7eb", background: "white", borderRadius: 10, padding: "6px 10px", cursor: "pointer" },
};
