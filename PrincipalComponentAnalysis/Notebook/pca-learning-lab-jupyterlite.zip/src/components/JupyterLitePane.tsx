import React from "react";

/**
 * JupyterLite runs fully in the browser (Pyodide/Pyolite) and is served as static files.
 * After you build it into `public/jupyterlite`, you can embed it here.
 *
 * Build command (from repo root):
 *   python -m pip install -r jupyterlite/requirements.txt
 *   jupyter lite build --contents jupyterlite/content --output-dir public/jupyterlite
 */
export function JupyterLitePane(props: { notebookPath?: string }) {
  // `path=` opens a file in JupyterLab; `urlpath=lab/tree/...` also works in many setups.
  const path = encodeURIComponent(props.notebookPath ?? "PCA_McDonald_DA.ipynb");
  const src = `/jupyterlite/lab/index.html?path=${path}`;

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={styles.note}>
        <div style={{ fontWeight: 700 }}>Run (JupyterLite)</div>
        <div style={{ fontSize: 12, opacity: 0.85 }}>
          If you see a 404, build JupyterLite into <code>public/jupyterlite</code> (see README).
        </div>
      </div>
      <iframe title="JupyterLite" src={src} style={styles.iframe} />
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  note: { padding: 12, borderBottom: "1px solid #e5e7eb" },
  iframe: { border: 0, width: "100%", height: "100%", flex: 1 }
};
