import React, { useMemo, useRef, useState } from "react";

export type ChatMessage = { role: "user" | "assistant"; content: string };

export function ChatPane(props: {
  activeContext?: { label: string; text: string } | null;
  onQuickAction?: (action: "explain_plot" | "quiz_me" | "whats_next") => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "🤖 What would you like to explore?" },
  ]);
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement | null>(null);

  const contextBanner = useMemo(() => {
    if (!props.activeContext) return null;
    return (
      <div style={styles.context}>
        <div style={{ fontWeight: 700 }}>Context: {props.activeContext.label}</div>
        <div style={{ whiteSpace: "pre-wrap", fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace", fontSize: 12 }}>
          {props.activeContext.text.slice(0, 600)}
          {props.activeContext.text.length > 600 ? "…" : ""}
        </div>
      </div>
    );
  }, [props.activeContext]);

  function send() {
    const trimmed = draft.trim();
    if (!trimmed) return;
    setMessages((m) => [...m, { role: "user", content: trimmed }, { role: "assistant", content: "(Wire this to your LLM backend.)" }]);
    setDraft("");
    requestAnimationFrame(() => endRef.current?.scrollIntoView({ behavior: "smooth" }));
  }

  return (
    <div style={styles.wrap}>
      <div style={styles.header}>
        <div style={{ fontWeight: 700 }}>Chatbot</div>
        <div style={styles.actions}>
          <button style={styles.actionBtn} onClick={() => props.onQuickAction?.("explain_plot")}>Explain this plot</button>
          <button style={styles.actionBtn} onClick={() => props.onQuickAction?.("quiz_me")}>Quiz me</button>
          <button style={styles.actionBtn} onClick={() => props.onQuickAction?.("whats_next")}>What’s next?</button>
        </div>
      </div>

      <div style={styles.history}>
        {contextBanner}
        {messages.map((msg, i) => (
          <div key={i} style={{ ...styles.msg, ...(msg.role === "user" ? styles.userMsg : styles.botMsg) }}>
            {msg.content}
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <div style={styles.inputRow}>
        <input
          style={styles.input}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Type your question..."
          onKeyDown={(e) => (e.key === "Enter" ? send() : undefined)}
        />
        <button style={styles.sendBtn} onClick={send} aria-label="Send">➤</button>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  wrap: { height: "100%", display: "flex", flexDirection: "column" },
  header: { padding: 12, borderBottom: "1px solid #e5e7eb" },
  actions: { display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" },
  actionBtn: { border: "1px solid #e5e7eb", background: "white", borderRadius: 12, padding: "6px 10px", cursor: "pointer" },
  history: { flex: 1, overflow: "auto", padding: 12, display: "flex", flexDirection: "column", gap: 10 },
  msg: { padding: 10, borderRadius: 12, maxWidth: "90%", whiteSpace: "pre-wrap", lineHeight: 1.35 },
  userMsg: { alignSelf: "flex-end", background: "#111827", color: "white" },
  botMsg: { alignSelf: "flex-start", background: "#f3f4f6" },
  inputRow: { display: "flex", gap: 8, padding: 12, borderTop: "1px solid #e5e7eb" },
  input: { flex: 1, border: "1px solid #e5e7eb", borderRadius: 12, padding: "10px 12px" },
  sendBtn: { border: "1px solid #e5e7eb", background: "white", borderRadius: 12, padding: "10px 14px", cursor: "pointer" },
  context: { border: "1px solid #e5e7eb", background: "#fff7ed", borderRadius: 12, padding: 10 },
};
