import React, { useEffect, useMemo, useState } from "react";
import Notebook from "@thomasvu/react-jupyter-notebook";
import "katex/dist/katex.min.css"; // for math rendering (used by many notebook renderers)
import { JupyterLitePane } from "./JupyterLitePane";

import type { Notebook as NB, Step } from "../lib/notebook";
import { cellToPlainText, extractStepsFromMarkdownHeaders } from "../lib/notebook";

export function NotebookPane(props: {
  notebookUrl: string;
  onSelectContext?: (ctx: { label: string; text: string } | null) => void;
  onStepChange?: (stepIndex: number, steps: Step[]) => void;
}) {
  const [nb, setNb] = useState<NB | null>(null);
  const [stepIdx, setStepIdx] = useState(0);
  const [tab, setTab] = useState<"view" | "run">("view");

  useEffect(() => {
    fetch(props.notebookUrl)
      .then((r) => r.json())
      .then((json) => setNb(json))
      .catch((e) => console.error("Failed to load notebook", e));
  }, [props.notebookUrl]);

  const steps = useMemo(() => (nb ? extractStepsFromMarkdownHeaders(nb) : []), [nb]);

  useEffect(() => {
    if (steps.length) props.onStepChange?.(stepIdx, steps);
  }, [stepIdx, steps, props]);

  function selectCell(index: number) {
    if (!nb) return;
    const cell = nb.cells[index];
    props.onSelectContext?.({ label: `Cell ${index} (${cell.cell_type})`, text: cellToPlainText(cell) });
  }

  if (!nb) return <div style={{ padding: 12 }}>Loading notebook…</div>;

  return (
    <div style={styles.wrap}>
      <div style={styles.toolbar}>
        <div style={styles.stepRow}>
          <button style={styles.navBtn} onClick={() => setStepIdx((s) => Math.max(0, s - 1))} disabled={stepIdx === 0}>
            ◀
          </button>
          <div style={{ fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {steps[stepIdx]?.title ?? "Notebook"}
          </div>
          <button
            style={styles.navBtn}
            onClick={() => setStepIdx((s) => Math.min(steps.length - 1, s + 1))}
            disabled={stepIdx >= steps.length - 1}
          >
            ▶
          </button>
        </div>

        <div style={styles.hint}>
          Guided prompt: <span style={{ fontWeight: 600 }}>"What should I notice here?"</span>
        </div>
      </div>

      <div style={styles.nbWrap}>
        {/* 
          react-jupyter-notebook is primarily a renderer.
          For clickable/annotatable cells, you can:
          - fork/wrap its cell renderer, or
          - render cells yourself using nbformat + your own components.

          As a lightweight placeholder, we render the notebook and provide a cell index jump list below.
        */}
        <Notebook rawIpynb={nb as any} />
      </div>

      <div style={styles.cellPicker}>
        <div style={{ fontSize: 12, opacity: 0.8 }}>Click a cell to attach it as chat context:</div>
        <div style={styles.cellButtons}>
          {nb.cells.slice(0, 24).map((_, i) => (
            <button key={i} style={styles.cellBtn} onClick={() => selectCell(i)}>
              {i}
            </button>
          ))}
          {nb.cells.length > 24 ? <span style={{ fontSize: 12, opacity: 0.7 }}>… ({nb.cells.length} cells)</span> : null}
        </div>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  wrap: { height: "100%", display: "flex", flexDirection: "column" },
  toolbar: { padding: 12, borderBottom: "1px solid #e5e7eb", display: "flex", flexDirection: "column", gap: 8 },
  stepRow: { display: "flex", alignItems: "center", gap: 8 },
  navBtn: { border: "1px solid #e5e7eb", background: "white", borderRadius: 10, padding: "6px 10px", cursor: "pointer" },
  hint: { fontSize: 12, opacity: 0.85 },
  tabBar: { display: "flex", gap: 8, alignItems: "center", padding: "10px 12px", borderBottom: "1px solid #e5e7eb" },
  tabBtn: { border: "1px solid #e5e7eb", background: "white", borderRadius: 999, padding: "6px 10px", cursor: "pointer", fontSize: 12 },
  tabBtnActive: { background: "#111827", color: "white", borderColor: "#111827" },
  nbWrap: { flex: 1, overflow: "auto", padding: 12 },
  cellPicker: { borderTop: "1px solid #e5e7eb", padding: 12, display: "flex", flexDirection: "column", gap: 8 },
  cellButtons: { display: "flex", gap: 6, flexWrap: "wrap" },
  cellBtn: { border: "1px solid #e5e7eb", background: "white", borderRadius: 10, padding: "4px 8px", cursor: "pointer", fontSize: 12 },
};
