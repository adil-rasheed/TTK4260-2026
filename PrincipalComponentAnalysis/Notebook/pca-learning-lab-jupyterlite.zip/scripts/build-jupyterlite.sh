#!/usr/bin/env bash
set -euo pipefail
python -m pip install -r jupyterlite/requirements.txt
jupyter lite build --contents jupyterlite/content --output-dir public/jupyterlite
echo "Built JupyterLite into public/jupyterlite"
