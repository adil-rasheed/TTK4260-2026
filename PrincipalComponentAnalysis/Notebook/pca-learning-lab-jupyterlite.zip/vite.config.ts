import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// NOTE: We keep this config intentionally minimal.
// If you deploy behind a subpath, add `base: "/your-subpath/"`.
export default defineConfig({
  plugins: [react()],
});
